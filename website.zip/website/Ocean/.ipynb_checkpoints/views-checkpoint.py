from django.shortcuts import render

# Create your views here.
#from django.http import HttpResponse
#def homepage(request):
#    return HttpResponse("Hello, world. You're at the Homepage of DLSNPv1.")


from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseRedirect, HttpResponse
from .forms import HomeForm, UniquecodeForm, EmailForm
from .models import Dlsnp
from django.core.files import File
from django.core.mail import send_mail

import os
from project4.settings import BASE_DIR
tmppath = os.path.join(BASE_DIR, 'media/tmp_dlsnp')

import tarfile
import zipfile

import subprocess

import DLSNPv1.globalvars as Globalvars

def homepage(request):
    
    form = HomeForm(request.POST, request.FILES or None)
    if request.method == 'POST':

       if form.is_valid():
          form.save()
          uniquecodeis = request.POST.get('unique_code')
          Globalvars.y = uniquecodeis
          uploadedgenomeobject = Dlsnp.objects.get(unique_code=uniquecodeis)
          request.session['uploadedgenomeid'] = uploadedgenomeobject.id
          
          # take the names/values of selected tools
          #selected_tools = request.POST.getlist('tools')
          #request.session['selectedtools'] = selected_tools
          #for i in request.session['selectedtools']:
          #    print(i)
          
          # take the code/name of selected reference genome
          #selected_ref = request.POST.get('reference_genomes')
          #request.session['selectedref'] = selected_ref
          
          # send unique code to user email 
          useremailis = request.POST.get('user_email')
          Globalvars.z = useremailis
          if useremailis != 'liulabdellserver@gmail.com':
          #request.session['useremailis'] = request.POST.get('user_email')
               send_mail('Your Unique Code', 'Your unique code is '+uniquecodeis, 'liulabdellserver@gmail.com', [useremailis], fail_silently=False)
          
          # take the value of genus_species
          #request.session['genusspecies'] = request.POST.get('genus_species')
          
          return redirect('annotation')
          #return HttpResponseRedirect('process/')
    return render(request, 'DLSNPv1/homepage.html', {'form': form})

def annotation(request):
    fileidis = request.session['uploadedgenomeid']
    annotationobject = get_object_or_404(Dlsnp, pk=fileidis)
    #annotationtools = request.session['selectedtools']
    #selectedreference = request.session['selectedref']
    #binomial = request.session['genusspecies']
    #makerunningfiles(fileidis, annotationobject.genomefile, annotationtools, selectedreference, binomial)
    makerunningfiles(fileidis, annotationobject.data_file)
    
    ###### the variable will be shared with websocket.py ########################################
    #Globalvars.x = fileidis
    Globalvars.x = '{}/{}/outlog.txt'.format(tmppath,fileidis)
    os.system('bash '+'{}/{}/bashbatch.sh >{}/{}/outlog.txt 2>&1 &'.format(tmppath,fileidis,tmppath,fileidis))

    #print(annotationtools)
    # pipeline function for genome annotation
    if request.GET.get('pipeline'):
        pipeline(fileidis, annotationobject.genomefile, annotationtools)
    
    # storage the annotation results with .zip format into related database by model's method 
        filewithpath = '{}/{}.zip'.format(tmppath,fileidis)
        filenameonly = '{}.zip'.format(fileidis)
        annotationobject.add_annotation_result(filewithpath, filenameonly)
    
    return render(request, 'GAv1/annotation.html')

def process(request):
    # storage the annotation results with .zip format into related database by model's method 
    fileidis = request.session['uploadedgenomeid']
    annotationobject = get_object_or_404(Annotation, pk=fileidis)
    filewithpath = '{}/AnnotateResults_{}.zip'.format(tmppath,fileidis)
    filenameonly = 'AnnotateResults_{}.zip'.format(fileidis)
    annotationobject.add_annotation_result(filewithpath, filenameonly)
    
    #validate unique code of user and then download result
    yourcode = UniquecodeForm(request.POST or None)
    if request.method == 'POST':
       if yourcode.is_valid():
          uniquecodeis = request.POST.get('uniquecode')
          try:
              annotationfile = Annotation.objects.get(unique_code=uniquecodeis)
          except:
              return render(request, 'GAv1/processpage.html',{'yourcode':yourcode, 'uniquecodeis':uniquecodeis})
          else:
              request.session['downloadfileid']=annotationfile.id
              return redirect('download')
    return render(request, 'GAv1/processpage.html',{'yourcode':yourcode})

def download(request):
    fileidis = request.session['downloadfileid']
    #downloadedfile = Annotation.objects.get(pk=fileidis)
    downloadedobject = get_object_or_404(Annotation, pk=fileidis)
    return render(request, 'GAv1/download.html', {'downloadedobject':downloadedobject})
    
def about(request):
    return render(request, 'GAv1/about.html')
def contact(request):
    return render(request, 'GAv1/contact.html')
def tutoral(request):
    return render(request, 'GAv1/tutoral.html')


def email(request):
    # input email address
    youremail = EmailForm(request.POST or None)
    if request.method == 'POST':
       if youremail.is_valid():
          youremailis = request.POST.get('email')
          request.session['emailis'] = request.POST.get('email')
          send_mail('Your Unique Code', 'Here is email test.', 'liulabdellserver@gmail.com', [youremailis], fail_silently=False)
          #return redirect('download')
    return render(request, 'GAv1/email.html',{'youremail':youremail})
###################### not view functions ################################


def makerunningfiles(fileid, file_for_annotation, selectedtools, selectedreference, binomial):
    fileidis = fileid
    binomialis = binomial
    
    if not os.path.exists('{}/{}'.format(tmppath,fileidis)):
        os.makedirs('{}/{}'.format(tmppath,fileidis))
    with open('{}/{}/sequence_for_annotation.txt'.format(tmppath,fileidis), 'wb+') as destination:
        for chunk in file_for_annotation.chunks():
            destination.write(chunk)
    with open('{}/{}/bashbatch.sh'.format(tmppath,fileidis), 'w+') as destination:
         destination.write("echo progress5\n")
         destination.write('export PATH="/home/ydong/Desktop/GAAP/Augustus/bin:/home/ydong/Desktop/GAAP/Augustus/scripts:/home/ydong/vapid/VAPiD-master:/home/ydong/vadr-dir/vadr:/home/ydong/ncbi-blast-2.10.1+-src/c++/ReleaseMT/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/home/ydong/.dotnet/tools:/opt/mssql-tools/bin:/home/ydong/prokka/bin:/home/ydong/Desktop/BEACON/BEACON_Source:/home/ydong:/home/ydong/TRF-master/build/src:/home/ydong/maker/bin:/home/ydong/RepeatMasker::/opt/mssql-tools/bin:/opt/mssql-tools/bin:/home/ydong/.local/bin:/home/ydong/GenemarkES/gmes_linux_64:$PATH"\n')
         destination.write("echo progress10\n")
         j = 0
         for i in selectedtools:
             #print(i)
             j = j+30
             if i == 'prokka':
                 os.makedirs('{}/{}/prokka'.format(tmppath,fileidis))
                 commandline = 'prokka --force --outdir '+'{}/{}/prokka'.format(tmppath,fileidis)+' '+'{}/{}/sequence_for_annotation.txt\n'.format(tmppath,fileidis)
                 destination.write(commandline)
                 #destination.write('\nzip -r -j -m {}/{}/prokka.zip'.format(tmppath,fileidis)+' '+'{}/{}/prokka'.format(tmppath,fileidis))
                 destination.write("\necho progress"+str(j)+"\n")
             if i == 'rasttk':
                 os.makedirs('{}/{}/rasttk'.format(tmppath,fileidis))
                 commandline1 = 'rast-create-genome --genetic-code 11 --domain Bacteria --contigs '+ '{}/{}/sequence_for_annotation.txt'.format(tmppath,fileidis)+' >'+'{}/{}/rasttk/annotation.gto\n'.format(tmppath,fileidis)
                 destination.write(commandline1)
                 commandline2 = 'rast-process-genome < '+'{}/{}/rasttk/annotation.gto '.format(tmppath,fileidis)+'> '+'{}/{}/rasttk/annotation.gto2\n'.format(tmppath,fileidis)
                 destination.write(commandline2)
                 commandline3 = 'rast-export-genome genbank < '+'{}/{}/rasttk/annotation.gto2 '.format(tmppath,fileidis)+'> '+'{}/{}/rasttk/annotation.gbk\n'.format(tmppath,fileidis)
                 destination.write(commandline3)
                 commandline4 = 'rast-export-genome gff < '+'{}/{}/rasttk/annotation.gto2 '.format(tmppath,fileidis)+'> '+'{}/{}/rasttk/annotation.gff\n'.format(tmppath,fileidis)
                 destination.write(commandline4)
                 #destination.write('\nzip -r -j -m {}/{}/rasttk.zip'.format(tmppath,fileidis)+' '+'{}/{}/rasttk'.format(tmppath,fileidis))
                 destination.write("\necho progress"+str(j)+"\n")
             
             if i == 'pgap':
                 os.makedirs('{}/{}/pgap'.format(tmppath,fileidis))
                 commandline1 = 'cp {}/{}/sequence_for_annotation.txt '.format(tmppath,fileidis)+'{}/{}/pgap\n'.format(tmppath,fileidis)
                 destination.write(commandline1)
                 commandline2 = 'pgap.py -r -o '+'{}/{}/pgap/result '.format(tmppath,fileidis)+'{}/{}/pgap/input.yaml\n'.format(tmppath,fileidis)
                 destination.write(commandline2)
                 #destination.write('\nzip -r -j -m {}/{}/pgap.zip'.format(tmppath,fileidis)+' '+'{}/{}/pgap'.format(tmppath,fileidis))
                 destination.write("\necho progress"+str(j)+"\n")
                 with open('{}/{}/pgap/submol.yaml'.format(tmppath,fileidis), 'w+') as subdestination:
                       subdestination.write('organism:\n')
                       subdestination.write("    genus_species: '"+binomialis+"'\n")
                 with open('{}/{}/pgap/input.yaml'.format(tmppath,fileidis), 'w+') as subdestination:
                       subdestination.write('fasta:\n')
                       subdestination.write('  class: File\n')
                       subdestination.write('  location: sequence_for_annotation.txt\n')
                       subdestination.write('submol:\n')
                       subdestination.write('  class: File\n')
                       subdestination.write('  location: submol.yaml\n')
                 
             if i == 'vadr':
                 os.makedirs('{}/{}/vadr'.format(tmppath,fileidis))
                 
                 destination.write('export VADRINSTALLDIR="/home/ydong/vadr-dir"\n')
                 destination.write('export VADRSCRIPTSDIR="$VADRINSTALLDIR/vadr"\n')
                 destination.write('export VADRMODELDIR="$VADRINSTALLDIR/vadr-models"\n')
                 destination.write('export VADRINFERNALDIR="$VADRINSTALLDIR/infernal/binaries"\n')
                 destination.write('export VADREASELDIR="$VADRINSTALLDIR/infernal/binaries"\n')
                 destination.write('export VADRHMMERDIR="$VADRINSTALLDIR/hmmer/binaries"\n')
                 destination.write('export VADRBIOEASELDIR="$VADRINSTALLDIR/Bio-Easel"\n')
                 destination.write('export VADRSEQUIPDIR="$VADRINSTALLDIR/sequip"\n')
                 destination.write('export VADRBLASTDIR="$VADRINSTALLDIR/ncbi-blast/bin"\n')
                 destination.write('export PERL5LIB="$VADRSCRIPTSDIR":"$VADRSEQUIPDIR":"$VADRBIOEASELDIR/blib/lib":"$VADRBIOEASELDIR/blib/arch":"$PERL5LIB"\n')
                 destination.write('export PATH="$VADRSCRIPTSDIR":"$PATH"\n')
                 destination.write('export PATH="$PATH:/home/ydong/.local/bin"\n')
                 
                 destination.write('v-annotate.pl '+'{}/{}/sequence_for_annotation.txt '.format(tmppath,fileidis)+'{}/{}/vadr/result\n'.format(tmppath,fileidis))
                 #destination.write('\nzip -r -j -m {}/{}/vadr.zip'.format(tmppath,fileidis)+' '+'{}/{}/vadr'.format(tmppath,fileidis))
                 destination.write("\necho progress"+str(j)+"\n")
                 with open('{}/{}/vadr/VADR_output_file_formats.txt'.format(tmppath,fileidis), 'w+') as subdestination:
                       subdestination.write("VADR output file formats can be found at the website below:\n")
                       subdestination.write('https://github.com/ncbi/vadr/blob/master/documentation/formats.md#coords')
                       
             if i == 'vapid':
                 os.makedirs('{}/{}/vapid'.format(tmppath,fileidis))    
                 # change working directory from log-in shell directory (namely /home/ydong)
                 destination.write('cd '+'{}/{}/vapid\n'.format(tmppath,fileidis))
                 destination.write('python /home/ydong/vapid/VAPiD-master/vapid.py --db /home/ydong/vapid/VAPiD-master/all_virus/database_with_sascov2/all_virus.fasta '+'{}/{}/sequence_for_annotation.txt '.format(tmppath,fileidis)+'/home/ydong/vapid/VAPiD-master/example2.sbt')
                 
                 destination.write('\ncd '+'{}/{}\n'.format(tmppath,fileidis))
                 #destination.write('\nzip -r -j -m {}/{}/vapid.zip'.format(tmppath,fileidis)+' '+'{}/{}/vapid'.format(tmppath,fileidis))
                 #destination.write('\nzip -r -m vapid.zip'+' '+'vapid')
                 destination.write("\necho progress"+str(j)+"\n")
                 # re-change working directory into log-in shell directory
                 destination.write('\ncd /home/ydong')
                 with open('{}/{}/vapid/VAPiD_output_file_formats.txt'.format(tmppath,fileidis), 'w+') as subdestination:
                       subdestination.write("VAPiD output file formats can be found at the website below:\n")
                       subdestination.write('https://github.com/rcs333/VAPiD')
             
             if i == 'funannotate':
                 #destination.write('cd {}/{}/augustus\n'.format(tmppath,fileidis))
                 destination.write('docker run --rm -v {}/{}:/tmp nextgenusfs/funannotate funannotate sort -i /tmp/sequence_for_annotation.txt -o /tmp/sequence_for_annotation_p1.txt\n'.format(tmppath,fileidis))
                 destination.write('docker run --rm -v {}/{}:/tmp nextgenusfs/funannotate funannotate mask -i /tmp/sequence_for_annotation_p1.txt -o /tmp/sequence_for_annotation_p2.txt\n'.format(tmppath,fileidis))
                 destination.write('docker run --rm -v {}/{}:/tmp nextgenusfs/funannotate funannotate predict -i /tmp/sequence_for_annotation_p2.txt -o /tmp/funannotate --augustus_species {} --species "{}"\n'.format(tmppath,fileidis,selectedreference,binomialis))
                 
                 destination.write('docker run --rm -v {}/{}:/tmp nextgenusfs/funannotate funannotate annotate -i /tmp/funannotate --cpus 2\n'.format(tmppath,fileidis))
                 ## zip augustus folder
                 #destination.write('\ncd '+'{}/{}\n'.format(tmppath,fileidis))
                 #destination.write('zip -r -m funannotate.zip'+' '+'funannotate')
                 destination.write("\necho progress"+str(j)+"\n")
                 # re-change working directory into log-in shell directory
                 destination.write('\ncd /home/ydong\n')
                 
             if i == 'genemarkes':
                 os.makedirs('{}/{}/genemarkes'.format(tmppath,fileidis))
                 destination.write('cp {}/{}/sequence_for_annotation.txt'.format(tmppath,fileidis)+' {}/{}/genemarkes/\n'.format(tmppath,fileidis))
                 destination.write('cd {}/{}/genemarkes\n'.format(tmppath,fileidis))
                 destination.write('gmes_petap.pl --sequence sequence_for_annotation.txt --ES\n')
                 ## zip augustus folder
                 destination.write('cd '+'{}/{}\n'.format(tmppath,fileidis))
                 #destination.write('zip -r -m genemarkes.zip'+' '+'genemarkes')
                 destination.write("\necho progress"+str(j)+"\n")
                 # re-change working directory into log-in shell directory
                 destination.write('\ncd /home/ydong\n')
             
             if i == 'augustus':
                 os.makedirs('{}/{}/augustus'.format(tmppath,fileidis))  
                 
                 ####### run some docker commands first ################ 
                 #os.system('cp {}/{}/sequence_for_annotation.txt'.format(tmppath,fileidis)+' {}/{}/gal/'.format(tmppath,fileidis))
                 #os.system('docker run -dit --name {}'.format(fileidis)+' -v {}/{}/gal:/usr/GAL_data cglabiicb/gal'.format(tmppath,fileidis))
                 #os.system('docker run -dit --name {}'.format(fileidis)+' -v {}/{}/gal'.format(tmppath,fileidis)+':/usr/GAL_data cglabiicb/gal; docker pull mysql; docker cp {}/{}/gal/{}.ini {}:/usr/GAL_data/;'.format(tmppath,fileidis,fileidis,fileidis)+' docker exec {}'.format(fileidis)+' python3 /usr/GAL/gal_manage.py --orgconfig=/usr/GAL_data/{}'.format(fileidis)+'.ini')
                 #os.system('docker pull mysql')
                 #os.system('docker exec {}'.format(fileidis)+' python3 /usr/GAL/gal_manage.py --orgconfig=/usr/GAL_data/{}'.format(fileidis)+'.ini')
                 
                 
                 ####### the second part of commands are wrote into a shell script #########
                 destination.write('cp {}/{}/sequence_for_annotation.txt'.format(tmppath,fileidis)+' {}/{}/augustus/\n'.format(tmppath,fileidis))
                 destination.write('cd {}/{}/augustus\n'.format(tmppath,fileidis))
                 destination.write('augustus --species={} sequence_for_annotation.txt > output.gff'.format(selectedreference,))
                 
                 #destination.write('docker run -dit --name {}'.format(fileidis)+' -v {}/{}/gal'.format(tmppath,fileidis)+':/usr/GAL_data cglabiicb/gal\n')
                 #destination.write('docker run --name sql{} mysql\n'.format(fileidis))
                 #destination.write('docker exec {}'.format(fileidis)+' python3 /usr/GAL/gal_manage.py --orgconfig=/usr/GAL_data/{}'.format(fileidis)+'.ini\n')
                 #destination.write('docker exec {}'.format(fileidis)+' cp -r /tmp/gal_tmp /usr/GAL_data\n')
                 #destination.write('docker kill {}'.format(fileidis)+'\n')
                 #destination.write('docker rm {}'.format(fileidis)+'\n')
                 #destination.write('docker rm sql{}'.format(fileidis)+'\n')
                 #destination.write('docker rmi sql{}'.format(fileidis)+'\n')
                 ## zip augustus folder
                 destination.write('\ncd '+'{}/{}\n'.format(tmppath,fileidis))
                 #destination.write('\nzip -r -m augustus.zip'+' '+'augustus')
                 destination.write("\necho progress"+str(j)+"\n")
                 # re-change working directory into log-in shell directory
                 destination.write('\ncd /home/ydong\n')
                 
                 #with open('{}/{}/gal/{}'.format(tmppath,fileidis,fileidis)+'.ini', 'w+') as subdestination:
                  #     subdestination.write("[OrganismDetails]\n")
                  #     subdestination.write('Organism:'+binomialis+'\n')
                  #     subdestination.write('version: 1\n')
                  #     subdestination.write('source_url:\n\n')
                  #     subdestination.write('[SequenceType]\n')
                  #     subdestination.write('SequenceType: chromosome\n\n')
                  #     subdestination.write('[AnnotationInfo]\n')
                  #     subdestination.write('blastp: yes\n')
                  #     subdestination.write('signalp: no\n')
                  #     subdestination.write('pfam: no\n')
                  #     subdestination.write('tmhmm: no\n\n')
                  #     subdestination.write('[filePath]\n')
                  #     subdestination.write('GenBank:\n')
                  #     subdestination.write('FASTA: /usr/GAL_data/sequence_for_annotation.txt\n')
                  #     subdestination.write('GFF:\n')
                  #     subdestination.write('Product:\n')
                  #     subdestination.write('LastZ:\n')
                  #     subdestination.write('SignalP:\n')
                  #     subdestination.write('pfam:\n')
                  #    subdestination.write('TMHMM:\n')
                  #    subdestination.write('interproscan:\n\n')
                  #     subdestination.write('[other]\n')
                   #    subdestination.write('program:AUGUSTUS\n')
                   #    subdestination.write('ReferenceGenome:'+selectedreference)
                       
                       
         destination.write("\necho progress95")
         #destination.write('\nzip -r -j {}/{}/{}.zip'.format(tmppath,fileidis,fileidis)+' '+'{}/{}'.format(tmppath,fileidis))
         #destination.write('\nzip -d {}/{}/{}.zip'.format(tmppath,fileidis,fileidis)+' '+'bashbatch.sh')
         #destination.write('\nmv '+'{}/{}/{}.zip'.format(tmppath,fileidis,fileidis)+' '+'{}'.format(tmppath))       
         destination.write('\ncd /home/ydong/Web_test/project4/media/tmp/{}'.format(fileidis))
         destination.write('\nzip -r AnnotateResults_{}.zip * -x bashbatch.sh'.format(fileidis))
         destination.write('\nmv '+'{}/{}/AnnotateResults_{}.zip'.format(tmppath,fileidis,fileidis)+' '+'{}'.format(tmppath))       
         #destination.write('\ntar -czvf {}.tar.gz {} --exclude={}/bashbatch.sh'.format(fileidis,fileidis,fileidis))
         destination.write("\necho All annotations finish successfully!")
         destination.write("\necho progress100")
         
    
def pipeline(fileid, file_for_annotation, selectedtools):
    fileidis = fileid
    #global bashpath
    #bashpath = '{}/{}/bashbatch.sh'.format(tmppath,fileidis)
    
    if not os.path.exists('{}/{}'.format(tmppath,fileidis)):
        os.makedirs('{}/{}'.format(tmppath,fileidis))
    with open('{}/{}/sequence_for_annotation.txt'.format(tmppath,fileidis), 'wb+') as destination:
        for chunk in file_for_annotation.chunks():
            destination.write(chunk)
    with open('{}/{}/bashbatch.sh'.format(tmppath,fileidis), 'w+') as destination:
         for i in selectedtools:
             #print(i)
             if i == 'prokka':
                 commandline = 'prokka --force --outdir '+'{}/{}'.format(tmppath,fileidis)+' '+'{}/{}/sequence_for_annotation.txt'.format(tmppath,fileidis)
                 destination.write(commandline)
                 
         destination.write("\necho All annotations finish successfully!")
    
    # run pipeline
    #process = subprocess.Popen(['bash','{}/{}/bashbatch.sh'.format(tmppath,fileidis)], stdout=subprocess.PIPE, universal_newlines=True)
    #method 2
    #stdout, stderr = process.communicate()
    #print(stdout)
    #method 3
    os.system('bash '+'{}/{}/bashbatch.sh'.format(tmppath,fileidis))
   
    with zipfile.ZipFile('{}/{}.zip'.format(tmppath,fileidis), 'w', ) as myzip:
         for root, dirs, files in os.walk('{}/{}'.format(tmppath,fileidis)):
            for onefile in files:
                onefile_with_path = os.path.join(root, onefile)
                myzip.write(onefile_with_path, arcname = os.path.basename(onefile_with_path))
               
    


         
 ###################################################
 






def handle_uploaded_file(f):
   
    with open('./GAv1/uploaded.txt', 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)

