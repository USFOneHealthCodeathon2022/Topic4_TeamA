from django.forms import ModelForm, widgets
from .models import Dlsnp
from django import forms

class HomeForm(ModelForm):
     
     class Meta:
         model = Dlsnp
         fields = ['data_file', 'unique_code']
         
     email_notice = forms.BooleanField(required=False)
     user_email=forms.EmailField(max_length=200)
     
class UniquecodeForm(forms.Form):
     uniquecode=forms.CharField(max_length=200)

class EmailForm(forms.Form):
     email=forms.EmailField(max_length=200)
