from django.apps import AppConfig


class Dlsnpv1Config(AppConfig):
    name = 'DLSNPv1'
