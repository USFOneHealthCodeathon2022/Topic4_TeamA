from django.apps import AppConfig


class OceanConfig(AppConfig):
    name = 'Ocean'
