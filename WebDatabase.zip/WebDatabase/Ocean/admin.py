from django.contrib import admin

# Register your models here.
#from .models import Codeathon

#class CodeathonAdmin(admin.ModelAdmin):
 #    list_display = ('accession',)

#admin.site.register(Codeathon, CodeathonAdmin)
